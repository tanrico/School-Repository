/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pt_2_programming_languages;

/**
 *
 * @author Rico Tan
 */
public class PT_2_Programming_Languages {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
